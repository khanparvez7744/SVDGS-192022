import { Component, OnInit } from '@angular/core';
import { user_mapping_modal } from '../add-user/user-mapping-modal';
import { userMappingService } from '../services/user-mapping-service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import * as $ from 'jquery'
import { add_user_role_modal } from '../add-role/add-user-role-modal';
// import "datatables.net";
// import "datatables.net-dt";
// import "datatables.net-buttons-dt";

@Component({
  selector: 'app-mapping',
  templateUrl: './mapping.component.html',
  styleUrls: ['./mapping.component.css']
})
export class MappingComponent implements OnInit {
  public tblMappingShow: boolean = false;
  userList: user_mapping_modal[];
  user: FormGroup;
  userName: String = "";
  savedUser: boolean = false;
  userRoleModal: add_user_role_modal[];

  constructor(private route: ActivatedRoute,
    private router: Router,
    public service: userMappingService, private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.fetchData();
    this.fetchRole();

    jQuery(document).ready(function () {
      (<any>jQuery('#mappingForm')).validate();
    });
  }



  fetchData() {

    this.user = this.formBuilder.group({
      id: [],
      name: [''],
      city: [''],
      email: [''],
      password: [''],
      pincode: [''],
      address: [''],
      state: [''],
      country: [''],
      mobileNumber: [''],
      designation: [''],
      role: [''],
      createdDate: [''],
    });



    this.service.getAllUser().subscribe((data: []) => {
      this.userList = data;
      // console.log('data all user',this.userList.value)
      this.tblMappingShow = true;
    })
  }


  updateUserData(item) {
    this.user.setValue(item);
    console.log("item", item);
  }

  fetchRole() {
    console.log('data all user role')

    this.service.getAllUserRole().subscribe((data: []) => {
      console.log('data all user role', data)
      this.userRoleModal = data;
      // this.filteredModel=data;
    })
    // this.filteredModel==this.modal;
    // this.modalArray=this.modal
  }


  updateEntry(item) {
    console.log("updated data", item);
    this.userName = this.user.value.name;
    this.service.updateUser(item).subscribe(data => {
      console.log("user updated at backend", data);
      this.savedUser = true;
      //  setTimeout(()=>{   
      //       this.router.navigate(
      //         ['/viewUser'],
      //         { queryParams: { updateUser: this.mappingModal.value.name } }
      //       );
      // }, 2000);
      this.fetchData();
    },
      error => console.log(error));
  }



}
