import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from "@angular/forms";
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { HttpClientModule } from '@angular/common/http';
import { AddRoleComponent } from './add-role/add-role.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { AddUserComponent } from './add-user/add-user.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { ReportsComponent } from './reports/reports.component';
import { ScheduleFlightComponent } from './schedule-flight/schedule-flight.component';
import { UpdateFlightComponent } from './update-flight/update-flight.component';
import { ViewFlightComponent } from './view-flight/view-flight.component';
import { ViewRoleComponent } from './view-role/view-role.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { HomeComponent } from './home/home.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { RightsidebarComponent } from './rightsidebar/rightsidebar.component';
import { MappingComponent } from './mapping/mapping.component';
import { StandConfigurationComponent } from './stand-configuration/stand-configuration.component';
import { AircraftDatafieldComponent } from './aircraft-datafield/aircraft-datafield.component';
import { StandIdentificationFieldComponent } from './stand-identification-field/stand-identification-field.component';
import { TestModeComponent } from './test-mode/test-mode.component';
import { SurveillanceHdViewComponent } from './surveillance-hd-view/surveillance-hd-view.component';
import { SurveillanceThermalViewComponent } from './surveillance-thermal-view/surveillance-thermal-view.component';
import { DataTablesModule } from 'angular-datatables';
import { PlayerControlsComponent } from './player-controls/player-controls.component';
import { StreamedianPlayerComponent } from './streamedian-player/streamedian-player.component';
import * as streamedian from 'streamedian/streamedian.js';
import { DeviceMappingComponent } from './device-mapping/device-mapping.component';
import { ApilogComponent } from './apilog/apilog.component';
import { SvdgsLogComponent } from './svdgs-log/svdgs-log.component';


@NgModule({
  declarations: [
    AppComponent,
    CreateEmployeeComponent,
    EmployeeDetailsComponent,
    EmployeeListComponent,
    AddRoleComponent,
    DashboardComponent,
    LoginComponent,
    AddUserComponent,
    ChangePasswordComponent,
    ForgotPasswordComponent,
    ManageUserComponent,
    NotificationsComponent,
    ReportsComponent,
    ScheduleFlightComponent,
    UpdateFlightComponent,
    ViewFlightComponent,
    ViewRoleComponent,
    ViewUserComponent,
    HomeComponent,
    SidebarComponent,
    RightsidebarComponent,
    MappingComponent,
    StandConfigurationComponent,
    AircraftDatafieldComponent,
    StandIdentificationFieldComponent,
    TestModeComponent,
    SurveillanceHdViewComponent,
    SurveillanceThermalViewComponent,
    PlayerControlsComponent,
    StreamedianPlayerComponent,
    DeviceMappingComponent,
    ApilogComponent,
    SvdgsLogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    DataTablesModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
