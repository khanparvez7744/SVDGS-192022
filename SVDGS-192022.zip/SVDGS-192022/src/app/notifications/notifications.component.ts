import { Component, OnInit } from '@angular/core';

import {schedule_flight_modal} from '../schedule-flight/schedule-flight-modal';
import {userService} from '../schedule-flight/schedule-flight-service';
import { interval } from 'rxjs';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  standModal:[];
  constructor(public service :userService) {
    // interval(4000).subscribe((x =>{
    //   this.fetchData();
    //   }));
   }

  ngOnInit() {
    this.fetchData();
  }
  fetchData(){
    this.service.getAllFlightStatus().subscribe((data :[])=>{
        console.log('data from getAllFlightStatus',data)
        this.standModal=data;
      })
      // this.modalArray=this.modal
  }

}
