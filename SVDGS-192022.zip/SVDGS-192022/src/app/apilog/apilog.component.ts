import { Component, OnInit } from '@angular/core';
import { userMappingService } from '../services/user-mapping-service';
import { DataTablesModule } from 'angular-datatables';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-apilog',
  templateUrl: './apilog.component.html',
  styleUrls: ['./apilog.component.css']
})

export class ApilogComponent implements OnInit {
  fileName = 'ExcelSheet.xlsx';
  public flight: Object = false;
  public chock: Object = false;
  public heart: Object = false;
  public stand: Object = false;
  public event: Object = false;
  apiLog: [];
  apiLogEvent: [];
  constructor(public service: userMappingService) {
  }
  ngOnInit() {
    this.ApiLogData();
    this.ApiLogDataEvent();
  }
  ApiLogData() {
    this.service.getApiLog().subscribe((data: []) => {
      this.apiLog = data;
    })
  }
  ApiLogDataEvent() {
    this.service.getApiLogEvent().subscribe((data: []) => {
      this.apiLogEvent = data;
    })
  }
  exportFlightInfo(): void {
    let element = document.getElementById('tblFlight');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  exportChock(): void {
    let element = document.getElementById('tblChock');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  exportHeart(): void {
    let element = document.getElementById('tblHeart');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  exportStand(): void {
    let element = document.getElementById('tblStand');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  exportEvent(): void {
    let element = document.getElementById('tblEvent');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  showFlightInfo() {
    this.flight = true;
    this.chock = false;
    this.heart = false;
    this.stand = false;
    this.event = false;
  }
  showChock() {
    this.flight = false;
    this.chock = true;
    this.heart = false;
    this.stand = false;
    this.event = false;
  }
  showHeart() {
    this.flight = false;
    this.chock = false;
    this.heart = true;
    this.stand = false;
    this.event = false;
  }
  showStand() {
    this.flight = false;
    this.chock = false;
    this.heart = false;
    this.stand = true;
    this.event = false;
  }
  showEvent() {
    this.flight = false;
    this.chock = false;
    this.heart = false;
    this.stand = false;
    this.event = true;
  }
}
