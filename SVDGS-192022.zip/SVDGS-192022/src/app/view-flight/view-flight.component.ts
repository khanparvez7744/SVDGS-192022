import { Component, OnInit } from '@angular/core';

import { schedule_flight_modal } from '../schedule-flight/schedule-flight-modal';
import { userService } from '../schedule-flight/schedule-flight-service';
import { interval } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';




@Component({
  selector: 'app-view-flight',
  templateUrl: './view-flight.component.html',
  styleUrls: ['./view-flight.component.css']
})
export class ViewFlightComponent implements OnInit {
  public tblFlightShow: boolean = false;
  modal = schedule_flight_modal[1000];
  filteredModel = schedule_flight_modal[1000];
  // students: Observable<Student[]>;  
  modalArray: schedule_flight_modal[];
  flightNo: String = '';
  savedFlight: boolean = false;


  constructor(public service: userService, private route: ActivatedRoute,
    private router: Router) {
    // interval(8000).subscribe((x =>{
    //   this.refreshPage();
    //   }));

  }

  ngOnInit() {
    this.fetchData();
  }


  refreshPage() {
    this.savedFlight = false;
  }



  editList(editBy: String) {
    this.filteredModel = [];

    this.modal.forEach((element: schedule_flight_modal) => {
      if (element.AOCC_SVDGS_Flight_Status == editBy)
        this.filteredModel.push(element);
    });
    console.log("data has been filtered by", editBy);
  }

  fetchData() {
    this.service.getAll().subscribe((data: []) => {
      this.tblFlightShow = true;
      console.log('data from getAll', data)
      this.filteredModel = data;

      console.log('data from getAll', this.filteredModel)

    })
    //  this.filteredModel==this.modal;
    // this.modalArray=this.modal
  }

  fetchFlightData() {
    this.service.getFlightDataByFlightNo().subscribe((data: []) => {
      console.log('data from getFlightDataByFlightNo', data)
      this.modal = data;
      this.filteredModel = data;
    })
    this.filteredModel == this.modal;
    // this.modalArray=this.modal
  }

  activate(data: schedule_flight_modal) {

    this.service.getActivateFlight(data).subscribe(data => {
    },
      error => console.log(error));

    this.modal.forEach(element => {
      if (element.AOCC_SVDGS_Flight_No == data.AOCC_SVDGS_Flight_No)
        element.activate = 'true';
    });


    console.log('activated ' + this.modal);

    this.flightNo = data.AOCC_SVDGS_Flight_No;
    this.savedFlight = true;

    // this.modal.forEach(function(value){
    //  value.activate=true;
    // })

    // this.modal.forEach(function(value){
    //   console.log(value)
    //  })

    // window.location.reload();
  }

  editFlight(item) {
    console.log('edit updateflight', item);
    this.router.navigate(['/updateflight', item.AOCC_SVDGS_Unique_Flight_ID]);
    // { queryParams: { username: "jimmy"}});
    // this.route.navigateByUrl('/page?id=37&username=jimmy');
  }



}
