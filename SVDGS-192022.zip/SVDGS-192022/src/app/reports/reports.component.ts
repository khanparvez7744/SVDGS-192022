import { Component, OnInit } from '@angular/core';
import { schedule_flight_modal } from '../schedule-flight/schedule-flight-modal';
import { userService } from '../schedule-flight/schedule-flight-service';
import { DataTablesModule } from 'angular-datatables';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})

export class ReportsComponent implements OnInit {
  fileName = 'ExcelSheet.xlsx';
  public tblReportShow: Object = false;
  modal = schedule_flight_modal[1000];
  constructor(public service: userService) { }
  ngOnInit() {
    // start common code for report
    $('#dwmData1, #dwmData2, #dwmData3').hide();
    $('#tblhide1, #tblhide2, #tblhide3').hide();
    $('#t1_wrapper, #t2_wrapper, #t3_wrapper').hide();
    $('#t1, #t2, #t3').hide();
    $('#exportBtn1').hide();
    $('#rptType').change(function () {
      $('#exportBtn1').hide();
      $('#dwmData1, #dwmData2, #dwmData3').hide();
      $('#tblhide1, #tblhide2, #tblhide3').hide();
      $('#t1, #t2, #t3').hide();
      $('#t1_wrapper, #t2_wrapper, #t3_wrapper').hide();
      $('#t' + $(this).val()).show();
      $('#t' + $(this).val() + '_wrapper').show();
      $('#tblhide' + $(this).val()).show();
      $('#dwmData' + $(this).val()).show();
      $('#exportBtn' + $(this).val()).show();
    });
    // end common code for report
    this.fetchData(); 
  }
  fetchData() {
    this.service.getAllReportData().subscribe((data: []) => {
      this.tblReportShow = true;
      console.log('data from report', data)
      data.forEach((ab: schedule_flight_modal) => {
        // console.log('aaaaa',ab)
        if (ab.chockonString == null) {
          ab.chockonString = 'N/A';
        }
        if (ab.chockOffString == null) {
          ab.chockOffString = 'N/A';
        }
      });
      this.modal = data;
    });
    // this.settingData();
  }
  settingData() {
  }
  getReportData(flitered: string) {
    console.log('filtered', flitered)
    this.service.getFilteredReportData(flitered).subscribe((data: []) => {
      data.forEach((ab: schedule_flight_modal) => {
        if (ab.chockonString == null) {
          ab.chockonString = 'N/A';
        }
        if (ab.chockOffString == null) {
          ab.chockOffString = 'N/A';
        }
      });
      this.modal = data;
    })
  }
  exportexcel(): void {
    let element = document.getElementById('t1');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
}