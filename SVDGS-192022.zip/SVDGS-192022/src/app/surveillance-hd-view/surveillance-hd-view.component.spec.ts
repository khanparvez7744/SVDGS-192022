import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveillanceHdViewComponent } from './surveillance-hd-view.component';

describe('SurveillanceHdViewComponent', () => {
  let component: SurveillanceHdViewComponent;
  let fixture: ComponentFixture<SurveillanceHdViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveillanceHdViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveillanceHdViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
