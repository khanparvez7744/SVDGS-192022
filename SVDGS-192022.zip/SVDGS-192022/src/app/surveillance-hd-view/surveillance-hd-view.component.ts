import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surveillance-hd-view',
  templateUrl: './surveillance-hd-view.component.html',
  styleUrls: ['./surveillance-hd-view.component.css']
})
export class SurveillanceHdViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
