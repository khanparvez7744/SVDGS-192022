import { Component, OnInit } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { add_user_role_modal } from '../add-role/add-user-role-modal';
import { userMappingService } from '../services/user-mapping-service';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css']
})
export class ViewRoleComponent implements OnInit {
  public tblRoleShow: boolean = false;
  userRoleModal: add_user_role_modal[];
  constructor(public service: userMappingService) { }

  ngOnInit() {
    this.fetchData();

  }


  fetchData() {
    this.service.getAllUserRole().subscribe((data: []) => {
      this.tblRoleShow = true;
      console.log('data all user role', data)
      this.userRoleModal = data;
      // this.filteredModel=data;
    })
    // this.filteredModel==this.modal;
    // this.modalArray=this.modal
  }


  deleteRole(roleId) {
    this.service.deleteRole(roleId).subscribe((data) => {

      console.log('Testing===============');

      this.fetchData();
    })
  }

}
