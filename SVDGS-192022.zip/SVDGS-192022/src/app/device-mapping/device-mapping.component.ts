import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-mapping',
  templateUrl: './device-mapping.component.html',
  styleUrls: ['./device-mapping.component.css']
})
export class DeviceMappingComponent implements OnInit {
  public tblDevMapShow: boolean = false;
  constructor() { }

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery("#devMapForm")).validate();
    });
    this.tblDevMapShow = true;
  }

}
