import { Component } from '@angular/core';
import { userMappingService } from './services/user-mapping-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SVDGS';



  constructor(public service: userMappingService) { }

  ngOnInit() {
    //  console.log(this.loginPage);
  }
}
