import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-mode',
  templateUrl: './test-mode.component.html',
  styleUrls: ['./test-mode.component.css']
})
export class TestModeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
