import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandIdentificationFieldComponent } from './stand-identification-field.component';

describe('StandIdentificationFieldComponent', () => {
  let component: StandIdentificationFieldComponent;
  let fixture: ComponentFixture<StandIdentificationFieldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandIdentificationFieldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandIdentificationFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
