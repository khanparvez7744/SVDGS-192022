import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stand-identification-field',
  templateUrl: './stand-identification-field.component.html',
  styleUrls: ['./stand-identification-field.component.css']
})
export class StandIdentificationFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery('#standIdenForm')).validate();
    });
  }

}
