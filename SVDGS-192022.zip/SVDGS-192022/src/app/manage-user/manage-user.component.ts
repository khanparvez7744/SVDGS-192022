import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { user_mapping_modal } from '../add-user/user-mapping-modal';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { userMappingService } from '../services/user-mapping-service';
import * as $ from 'jquery'
import { State } from 'datatables.net';
import { Airport } from '../schedule-flight/airport';
import { City } from '../schedule-flight/city';
import { add_user_role_modal } from '../add-role/add-user-role-modal';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})

export class ManageUserComponent implements OnInit {
  userId: String = "";
  savedUser: boolean = false;
  userName: String = "";
  // mappingModal: user_mapping_modal;
  mappingModal: FormGroup;
  cities: City[] = [];
  states: State[] = [];
  airports: Airport[] = [];
  state: string
  userRoleModal: add_user_role_modal[];
  constructor(private route: ActivatedRoute,
    private router: Router,
    public service: userMappingService, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.userId = this.route.snapshot.paramMap.get('id');
    console.log("this.userId", this.userId);
    this.fetchData();
    this.fetchRole();
    this.getStates();
    this.getAirports();
    // start hide show password
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');
    togglePassword.addEventListener('click', function (e) {
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
      this.classList.toggle('fa-eye');
    });
    // end hide show password
    jQuery(document).ready(function () {
      (<any>jQuery('#mngUserForm')).validate();
    });
  }
  fetchData() {
    this.mappingModal = this.formBuilder.group({
      id: [],
      name: [''],
      city: [''],
      email: [''],
      password: [''],
      pincode: [''],
      address: [''],
      state: [''],
      country: [''],
      mobileNumber: [''],
      designation: [''],
      role: [''],
      createdDate: [''],
    });
    this.service.getUser(this.userId).subscribe((data: any) => {
      // this.mappingModal=data;
      this.mappingModal.setValue(data);
      this.state = this.mappingModal.controls['state'].value;
      this.getCities();
      console.log('get data from db edit user', this.mappingModal.value);
    },
      error => console.log(error));
  }
  fetchRole() {
    console.log('data all user role')
    this.service.getAllUserRole().subscribe((data: []) => {
      console.log('data all user role', data)
      this.userRoleModal = data;
    })
  }
  getStates() {
    console.log('getStates')
    this.service.getStates().subscribe((data: []) => {
      console.log('getStates', data)
      this.states = data;
    })
  }
  getCities() {
    console.log('getCities')
    this.service.getCities(this.state).subscribe((data: []) => {
      console.log('getCities', data);
      this.cities = data;
    })
  }
  getAirports() {
    console.log('getAirports')
    this.service.getAirports().subscribe((data: []) => {
      console.log('getAirports', data)
      this.airports = data;
    })
  }
  updateData(data) {
    // console.log("this.mappingModal.value.name", this.mappingModal.value.name);
    this.userName = this.mappingModal.value.name;
    this.service.updateUser(data).subscribe(data => {
      console.log("user updated at backend", data);
      this.savedUser = true;
      setTimeout(() => {
        this.router.navigate(
          ['/viewUser'],
          { queryParams: { updateUser: this.mappingModal.value.name } }
        );
      }, 2000);
    },
      error => console.log(error));
  }
}