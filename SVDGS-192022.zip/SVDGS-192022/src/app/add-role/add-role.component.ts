import { Component, OnInit } from '@angular/core';
import { add_user_role_modal } from './add-user-role-modal';
import { userMappingService } from '../services/user-mapping-service';
import { interval } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})

export class AddRoleComponent implements OnInit {
  savedUser: boolean = false;
  userRoleModal: add_user_role_modal;
  roleName: String = '';
  checkUserMgmt: boolean;
  checkFtlOp: boolean;
  noRole: boolean;

  constructor(public service: userMappingService,
    public route: Router) {
    interval(10000).subscribe((x => {
      this.refreshPage();
    }));
  }

  refreshPage() {
    this.savedUser = false;
    this.noRole = false;
    // window.location.reload();
    // this.userRoleModal=null;
    // this.route.navigate(['/addRole']);
    // this.userRoleModal=new add_user_role_modal();
  }

  ngOnInit() {
    // jQuery(document).ready(function () {
    //   (<any>jQuery('#addRoleForm')).validate();
    // });
  }

  formSubmit(modal: add_user_role_modal) {
    console.log(modal["userManagement"]);
    console.log(modal["addUser"]);
    console.log(modal["manageUser"]);
    console.log(modal["viewUser"]);
    console.log(modal["flightOperation"]);
    console.log(modal["scheduleFlight"]);
    console.log(modal["updateFlight"]);
    console.log(modal["viewFlight"]);
    console.log(modal["settings"]);
    console.log(modal["sVDGSConfiguration"]);
    console.log(modal["notification"]);
    console.log(modal["surveillance"]);
    if (!modal["userManagement"]
      && !modal["addUser"]
      && !modal["manageUser"]
      && !modal["viewUser"]
      && !modal["flightOperation"]
      && !modal["scheduleFlight"]
      && !modal["updateFlight"]
      && !modal["viewFlight"]
      && !modal["settings"]
      && !modal["sVDGSConfiguration"]
      && !modal["notification"]
      && !modal["surveillance"]
      && !modal["miscellaneous"]) {
      this.noRole = true;
      console.log('ggggggggggggggggggggggggggg');
      return;
    }

    console.log("add_user_role_modal", modal);
    this.roleName = modal.roleName;
    this.service.saveUserRole(modal).subscribe(data => {
      console.log('user_mapping_modal ', data)
      this.savedUser = true;
    },
      error => console.log(error));
    // modal.reset();
    // window.location.reload();
  }

  checkAllUserMgmt(event) {
    const checked = event.target.checked;
    this.checkUserMgmt = checked;
  }

  checkAllFltOp(event) {
    const checked = event.target.checked;
    this.checkFtlOp = checked;
  }
}