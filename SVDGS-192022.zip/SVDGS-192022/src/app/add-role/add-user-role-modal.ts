export class add_user_role_modal {
	id: any
	roleName: String = "";
	userManagement: boolean;
	addUser: boolean;
	manageUser: boolean;
	viewUser: boolean;
	flightOperation: boolean;
	scheduleFlight: boolean;
	updateFlight: boolean;
	viewFlight: boolean;
	report: boolean;
	userRoleMapping: boolean;
	settings: boolean;
	sVDGSConfiguration: boolean;
	notification: boolean;
	surveillance: boolean;
	miscellaneous: boolean;
}