import { Component, OnInit } from '@angular/core';
import { user_mapping_modal } from '../add-user/user-mapping-modal';
import { userMappingService } from '../services/user-mapping-service';
import { ActivatedRoute, Router } from '@angular/router';
// import "datatables.net";
// import "datatables.net-dt";
// import "datatables.net-buttons-dt";

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  public tblUserShow: boolean = false;
  userModal: user_mapping_modal[];
  constructor(public service: userMappingService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.fetchData();
    // start view user
    // $('#tblUser').DataTable({
    //   language: {
    //     search: "",
    //     searchPlaceholder: "Search..."
    //   },
    //   dom: 'Bfrtip',
    //   buttons: {
    //     buttons: [
    //       { extend: 'csv', text: 'CSV <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-warning me-1' },
    //       { extend: 'excel', text: 'Excel <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-success me-1' },
    //       { extend: 'pdf', text: 'PDF <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-danger' }
    //     ]
    //   }
    // });
    // end view user
  }



  fetchData() {
    this.service.getAllUser().subscribe((data: []) => {
      this.tblUserShow = true;
      console.log('data all user', data)
      this.userModal = data;
      // this.filteredModel=data;
    })
  }


  editUser(item) {
    console.log('edit user', item);
    this.router.navigate(['/manageUser', item.id]);
    // { queryParams: { username: "jimmy"}});
    // this.route.navigateByUrl('/page?id=37&username=jimmy');
  }

}
