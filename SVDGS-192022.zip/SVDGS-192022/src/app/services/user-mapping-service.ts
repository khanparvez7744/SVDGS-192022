import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { user_mapping_modal } from '../add-user/user-mapping-modal';
import { Observable } from 'rxjs';
import { DataTablesModule } from 'angular-datatables';
import { HttpParams } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Injectable({
    providedIn: 'root'
})

export class userMappingService {
    constructor(public http: HttpClient) {
    }
    private baseUrl = 'http://localhost:8881/api/';
    loginPage: boolean = false;
    saveUserRole(modal: object): Observable<object> {
        console.log("service user role modal", modal);
        return this.http.post(this.baseUrl + "saveUserRole", modal);
    }
    saveUser(modal: object): Observable<object> {
        console.log("service user modal", modal);
        return this.http.post(this.baseUrl + "saveUser", modal);
    }
    updateUser(modal: object): Observable<object> {
        console.log("service update user modal", modal);
        return this.http.post(this.baseUrl + "updateUser", modal);
    }
    getApiLog(): Observable<object> {
        return this.http.get('https://jsonplaceholder.typicode.com/posts');
    }
    getApiLogEvent(): Observable<object> {
        return this.http.get('https://jsonplaceholder.typicode.com/posts');
    }
    getAllUser(): Observable<object> {
        console.log("get all user",);
        return this.http.get(this.baseUrl + "getAllUser");
    }
    deleteRole(id: number): Observable<Object> {
        return this.http.get(`${this.baseUrl}deleteRole/${id}`);
    }
    getAllUserRole(): Observable<object> {
        console.log("get all user role",);
        return this.http.get(this.baseUrl + "getAllUserRole");
    }
    getCities(stateCode): Observable<object> {
        console.log("get all user role",);
        return this.http.get(`${this.baseUrl}cities/${stateCode}`);
    }
    getStates(): Observable<object> {
        console.log("get all user role",);
        return this.http.get(this.baseUrl + "states");
    }
    getAirports(): Observable<object> {
        console.log("get all user role",);
        return this.http.get(this.baseUrl + "airports");
    }
    getRangingData(): Observable<object> {
        console.log("get all fetchSettingConfig",);
        return this.http.get(this.baseUrl + "getRangingParams");
    }
    getUserRole(id: number): Observable<Object> {
        return this.http.get(`${this.baseUrl}getUserRole/${id}`);
    }
    getUser(id): Observable<Object> {
        return this.http.get(`${this.baseUrl}getUser/${id}`);
    }
    saveStandConf(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "saveStandConf", modal);
    }
    saveRangingParams(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "rangingParam", modal);
    }
    saveLidarParams(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "lidarParams", modal);
    }
    saveObjectDetectionParams(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "objectDetectionParams", modal);
    }
    saveSpeedParams(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "speedParams", modal);
    }
    saveCenterlineParams(modal: object): Observable<object> {
        console.log("service stand configuration modal", modal);
        return this.http.post(this.baseUrl + "centerlineParams", modal);
    }
    login(modal: object): Observable<object> {
        console.log("service update user modal", modal);
        return this.http.post(this.baseUrl + "login", modal);
    }
}