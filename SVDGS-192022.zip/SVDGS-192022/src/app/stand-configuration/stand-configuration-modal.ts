export class stand_configuration_modal {

    standConfiguration:String;
    stopPointReference:String;
    stopDistance :String;
    tofarDistance:String; 
    manSpeed:String;
    

}



