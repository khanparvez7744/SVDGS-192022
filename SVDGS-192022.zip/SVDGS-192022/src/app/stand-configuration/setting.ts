export class setting {

    cpx:string;
    cpy:string;
    dx1:string;
    dx2:string;
    dx3:string;
    dx4:string;
    dx5:string;
    dx6:string;
    dx7:string;
    dx8:string;
    dx9:string;
    dx10:string;
    dy1:string;
    dy2:string;
    dy3:string;
    dy4:string;
    dy5:string
    dy6:string;
    dy7:string;
    dy8:string;
    dy9:string;
    dy10:string;
    

}