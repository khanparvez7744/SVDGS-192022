import { Component, OnInit } from '@angular/core';
import {stand_configuration_modal} from './stand-configuration-modal';
import { userMappingService } from '../services/user-mapping-service';
import { setting } from './setting';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { Airport } from '../schedule-flight/airport';
import { Country } from '../schedule-flight/Country';


@Component({
  selector: 'app-stand-configuration',
  templateUrl: './stand-configuration.component.html',
  styleUrls: ['./stand-configuration.component.css']
})
export class StandConfigurationComponent implements OnInit {
  savedUser: boolean = false;
  modal: stand_configuration_modal;
  userName:String='';
  selectedIndex: number;
  standConfiguration:String;

 

permissions=[{value: 6, name: "delete-wews", checked: false},
{value: 5, name: "update-user", checked: false},
{value: 4, name: "search-user", checked: false},
{value: 3, name: "list-user", checked: false},
{value: 2, name: "find-user", checked: false},
{value: 1, name: "create-user", checked: true}]


settings : setting[]
setting : setting

rangingParamsForm : FormGroup;
lidarForm : FormGroup;
objectDetectionForm : FormGroup;
centerLineForm : FormGroup;
speedForm : FormGroup;
dx1List: string[]
dy1List: string[]
dx2List: string[]
dy2List: string[]
dx3List: string[]
dy3List: string[]
dx4List: string[]
dy4List: string[]
dx5List: string[]
dy5List: string[]
dx6List: string[]
dy6List: string[]
dx7List: string[]
dy7List: string[]
dx8List: string[]
dy8List: string[]
dx9List: string[]
dy9List: string[]
dx10List: string[]
dy10List: string[]
cpxList: string[]
cpyList: string[]

airports : Airport[]=[];
countries :Country[]=[];
countryCode : string;
AOCC_SVDGS_Airport_Code :string;




  constructor(public service: userMappingService,private formBuilder: FormBuilder,) { }

  ngOnInit() {

    this.getAirports();
    // jQuery(document).ready(function () {
    //   (<any>jQuery('#frmLidar')).validate();
    // });
    // jQuery(document).ready(function () {
    //   (<any>jQuery('#frmObject')).validate();
    // });
    // jQuery(document).ready(function () {
    //   (<any>jQuery('#frmSpeed')).validate();
    // });
    // jQuery(document).ready(function () {
    //   (<any>jQuery('#frmCenterline')).validate();
    // });

    this.fetchSettingConfig();
    this.getCountryData();
  }


  fetchSettingConfig(){

    this.rangingParamsForm = this.formBuilder.group({
      dx1: [''],
      dy1: [''],
      dx2: [''],
      dy2: [''],
      dx3: [''],
      dy3: [''],
      dx4: [''],
      dy4: [''],
      dx5: [''],
      dy5: [''],
      dx6: [''],
      dy6: [''],
      dx7: [''],
      dy7: [''],
      dx8: [''],
      dy8: [''],
      dx9: [''],
      dy9: [''],
      dx10: [''],
      dy10: [''],
      cpx: [''],
      cpy: [''],
      stopPoint : [''],
      AOCC_SVDGS_Airport_Code : [''],
      countryCode :['']
      
    });

    this.lidarForm = this.formBuilder.group({
      hostName: [''],
      udpPort: [''],
      AOCC_SVDGS_Airport_Code : [''],
      countryCode :['']
    
    });

    this.objectDetectionForm = this.formBuilder.group({
      folderPath: [''],
      modalPath: [''],
      device: [''],
      confidence: [''],
      iou: [''],
      manDetect: [''],
      AOCC_SVDGS_Airport_Code : [''],
      countryCode :['']
    
    });
    this.speedForm = this.formBuilder.group({
      speed: [''],
      AOCC_SVDGS_Airport_Code : [''],
      countryCode :['']
    
    });
    this.centerLineForm = this.formBuilder.group({
      rightPixel: [''],
      leftPixel: [''],
      AOCC_SVDGS_Airport_Code : [''],
      countryCode :['']
    
    });

    this.service.getRangingData().subscribe((data :[])=>{
        console.log('data getRangingData ',data)
        this.settings=data;
        this.setting= this.settings[0];

        console.log('data getRangingData ',this.setting)
       
        this.dx1List = this.setting.dx1.split("#");
        this.dy1List = this.setting.dy1.split("#");
        this.dx2List = this.setting.dx2.split("#");
        this.dy2List = this.setting.dy2.split("#");
        this.dx3List = this.setting.dx3.split("#");
        this.dy3List = this.setting.dy3.split("#");
        this.dx4List = this.setting.dx4.split("#");
        this.dy4List = this.setting.dy4.split("#");
        this.dx5List = this.setting.dx5.split("#");
        this.dy5List = this.setting.dy5.split("#");
        this.dx6List = this.setting.dx6.split("#");
        this.dy6List = this.setting.dy6.split("#");
        this.dx7List = this.setting.dx7.split("#");
        this.dy7List = this.setting.dy7.split("#");
        this.dx8List = this.setting.dx8.split("#");
        this.dy8List = this.setting.dy8.split("#");
        this.dx9List = this.setting.dx9.split("#");
        this.dy9List = this.setting.dy9.split("#");
        this.dx10List = this.setting.dx10.split("#");
        this.dy10List = this.setting.dy10.split("#");
        this.cpxList = this.setting.cpx.split("#");
        this.cpyList = this.setting.cpy.split("#");

        console.log(this.dx3List);
        // this.filteredModel=data;
      })

    

      // this.filteredModel==this.modal;
      // this.modalArray=this.modal
  }
  getCountryData()
  {

     this.countries =[{"countryCode":"India","countryName":"India"}]
  }

  onChangeCountry(item)
  {
    this.countryCode =item;
    console.log(" country " + this.countryCode)
  }

  onChangeAirportCode(item)
  {
    this.AOCC_SVDGS_Airport_Code =item;
    console.log(" AOCC_SVDGS_Airport_Code " + this.AOCC_SVDGS_Airport_Code)


  }
  
  
  getAirports(){
    console.log('getAirports')
    this.service.getAirports().subscribe((data :[] )=>{
        console.log('getAirports',data)
        this.airports=data;
        // this.filteredModel=data;
      })
   
  }

  rangingParamFormSubmit(formData) {
    console.log("rangingParamFormSubmit", formData.value);
    formData.saveOrUpdate = true
    this.service.saveRangingParams(formData).subscribe(data => {
       console.log('ranging params aa gya ', data)
    },
      error => console.log('ranging params'+error));

    let id = 8;

  }

  lidarFormSubmit(formData) {
    console.log("lidarFormSubmit in Successfully  flight", formData.value);
    formData.saveOrUpdate = true
    this.service.saveLidarParams(formData).subscribe(data => {
       console.log('ranging params aa gya ', data)
    },
      error => console.log('ranging params'+error));
    let id = 8;

  }

  objectDetectionFormSubmit(formData) {
    console.log("lidarFormSubmit in Successfully  flight", formData.value);
    formData.saveOrUpdate = true
    this.service.saveObjectDetectionParams(formData).subscribe(data => {
       console.log('ranging params aa gya ', data)
    },
      error => console.log('ranging params'+error));
    let id = 8;

  }


  speedFormSubmit(formData) {
    console.log("lidarFormSubmit in Successfully  flight", formData.value);
    formData.saveOrUpdate = true
    this.service.saveSpeedParams(formData).subscribe(data => {
       console.log('ranging params aa gya ', data)
    },
      error => console.log('ranging params'+error));
    let id = 8;

  }

  centerLineFormSubmit(formData) {
    console.log("lidarFormSubmit in Successfully  flight", formData.value);
    formData.saveOrUpdate = true
    this.service.saveCenterlineParams(formData).subscribe(data => {
       console.log('ranging params aa gya ', data)
    },
      error => console.log('ranging params'+error));
    let id = 8;

  }

  changeRadio(value){
    console.log("user updated at backend",value);
    this.permissions.forEach(a=> {
        if(a.name==value){
          a.checked=true;
        }else{
          a.checked=false;
        }
    });
    
  }


  saveConfig(value){
    console.log("user updated at backend",value);
    console.log("standConfiguration",this.standConfiguration);
  }

  updateData(data:stand_configuration_modal){
    this.userName=data.standConfiguration;
    this.service.updateUser(data).subscribe(data => {
      console.log("user updated at backend",data);
      this.savedUser=true;
    },
      error => console.log(error));
      
  }

}
