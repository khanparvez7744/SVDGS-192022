import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandConfigurationComponent } from './stand-configuration.component';

describe('StandConfigurationComponent', () => {
  let component: StandConfigurationComponent;
  let fixture: ComponentFixture<StandConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
