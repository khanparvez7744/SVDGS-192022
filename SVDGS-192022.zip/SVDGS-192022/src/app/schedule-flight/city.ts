export class City {

    cityCode:String;
    cityDesc:String;

}