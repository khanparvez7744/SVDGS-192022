export class Airport {

    AOCC_SVDGS_Airport_Name:String;
    AOCC_SVDGS_Airport_Code:String;

}