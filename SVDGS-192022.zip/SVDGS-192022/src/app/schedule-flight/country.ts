export class Country {

    countryName:String;
    countryCode:String;

}