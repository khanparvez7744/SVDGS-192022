export class schedule_flight_modal {
    
    AOCC_SVDGS_Airport_Code:String;
    AOCC_SVDGS_Unique_Flight_ID:String;
    AOCC_SVDGS_Flight_No:String;
    AOCC_SVDGS_AC_Type:String; 
    AOCC_SVDGS_Arr_Dep:String;
    AOCC_SVDGS_Stand:String;
    AOCC_SVDGS_ST_AD:String;
    AOCC_SVDGS_ET_AD:String;
    AOCC_SVDGS_AT_AD:String;
    AOCC_SVDGS_Flight_Qualifier:String;
    AOCC_SVDGS_O_D:String;
    AOCC_SVDGS_Reg_No:String;
    AOCC_SVDGS_VIA:String;
    AOCC_SVDGS_Code_Share_Flight:String;
    AOCC_SVDGS_Flight_Status:String;
    AOCC_SVDGS_Bag_Belt:String;
    chocksOn:String;
    chockOff:String;
    chockonString:String;
    chockOffString:String;
    countryCode :string
    saveOrUpdate:boolean;
    activate :boolean =false;

}



