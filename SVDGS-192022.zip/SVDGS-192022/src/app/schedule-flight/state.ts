export class State {

    stateCode: String;
    stateDesc: String;

}