import { Component, OnInit } from '@angular/core';
import { user_mapping_modal } from './user-mapping-modal';
import { userMappingService } from '../services/user-mapping-service';
import { add_user_role_modal } from '../add-role/add-user-role-modal'
import { interval } from 'rxjs';
import * as $ from 'jquery'
import { City } from '../schedule-flight/city';
import { State } from '../schedule-flight/state';
import { Airport } from '../schedule-flight/airport';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})

export class AddUserComponent implements OnInit {
  savedUser: boolean = false;
  userName: String = "";
  mappingModal: user_mapping_modal;
  userRoleModal: add_user_role_modal[];
  cities: City[] = [];
  states: State[] = [];
  airports: Airport[] = [];
  state: string
  constructor(public service: userMappingService) { }
  ngOnInit() {
    this.fetchData();
    interval(10000).subscribe((x => {
      this.refreshPage();
    }))
    // start hide show password
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');
    togglePassword.addEventListener('click', function (e) {
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
      this.classList.toggle('fa-eye');
    });
    // end hide show password
    this.getStates();
    this.getAirports();
  }
  refreshPage() {
    this.savedUser = false;
  }
  fetchData() {
    console.log('data all user role')
    this.service.getAllUserRole().subscribe((data: []) => {
      console.log('data all user role', data)
      this.userRoleModal = data;
      // this.filteredModel=data;
    })
    // this.filteredModel==this.modal;
    // this.modalArray=this.modal
  }
  getStates() {
    console.log('getStates')
    this.service.getStates().subscribe((data: []) => {
      console.log('getStates', data)
      this.states = data;
    })
  }
  getCities() {
    console.log('getCities')
    this.service.getCities(this.state).subscribe((data: []) => {
      console.log('getCities', data);
      this.cities = data;
      // this.filteredModel=data;
    })
  }
  getAirports() {
    console.log('getAirports')
    this.service.getAirports().subscribe((data: []) => {
      console.log('getAirports', data)
      this.airports = data;
      // this.filteredModel=data;
    })
  }
  formSubmit(modal: user_mapping_modal) {
    console.log("user_mapping_modal", modal);
    this.userName = modal.name;
    this.service.saveUser(modal).subscribe(data => {
      console.log('user_mapping_modal ', data)
      this.savedUser = true;
    },
      error => console.log(error));
    let id = 8;
  }
}