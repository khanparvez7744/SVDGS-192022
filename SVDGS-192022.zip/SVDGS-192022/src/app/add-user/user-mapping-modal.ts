export class user_mapping_modal {
    name: String;
    password: String;
    email: String;
    mobileNumber: String;
    address: String;
    designation: String;
    roleId: String;
    pincode: String;
    city: String;
    state: String;
    country: String;
}
