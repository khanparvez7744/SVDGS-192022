import { Component, OnInit } from '@angular/core';
import { userMappingService } from '../services/user-mapping-service';
import { DataTablesModule } from 'angular-datatables';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-svdgs-log',
  templateUrl: './svdgs-log.component.html',
  styleUrls: ['./svdgs-log.component.css']
})

export class SvdgsLogComponent implements OnInit {
  fileName = 'ExcelSheet.xlsx';
  public temp: Object = false;
  public temp2: Object = false;
  apiLog: [];
  apiLog2: [];
  public dockingLogg: Object = false;
  public htLogg: Object = false;
  constructor(public service: userMappingService) { }
  ngOnInit() {
    this.ApiLogData();
  }
  ApiLogData() {
    this.service.getApiLog().subscribe((data: []) => {
      this.apiLog = data;
      this.temp = true;
    })
  }
  exportSvdgsLog(): void {
    let element = document.getElementById('tblSvdgsLog');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  ApiLogData2() {
    this.service.getApiLog().subscribe((data: []) => {
      this.apiLog = data;
      this.temp = true;
    })
  }
  exportSvdgsLog2(): void {
    let element = document.getElementById('tblSvdgsLog2');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }
  dummy = [
    {
      sr: 1,
      flightId: 2323,
      flightNo: "DEL234",
      logData: "abcd",
      dataTime: "2023-02-18 18:26:37"
    },
    {
      sr: 2,
      flightId: 2323,
      flightNo: "DEL234",
      logData: "abcd",
      dataTime: "2023-02-18 18:26:37"
    },
    {
      sr: 3,
      flightId: 2323,
      flightNo: "DEL234",
      logData: "abcd",
      dataTime: "2023-02-18 18:26:37"
    },
    {
      sr: 4,
      flightId: 2323,
      flightNo: "DEL234",
      logData: "abcd",
      dataTime: "2023-02-18 18:26:37"
    },
    {
      sr: 5,
      flightId: 2323,
      flightNo: "DEL234",
      logData: "abcd",
      dataTime: "2023-02-18 18:26:37"
    }
  ];
  dockingLog() {
    this.dockingLogg = true;
    this.htLogg = false;
  }
  htLog() {
    this.htLogg = true;
    this.dockingLogg = false;
  }
}
