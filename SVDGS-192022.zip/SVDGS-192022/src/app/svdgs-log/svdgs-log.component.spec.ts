import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SvdgsLogComponent } from './svdgs-log.component';

describe('SvdgsLogComponent', () => {
  let component: SvdgsLogComponent;
  let fixture: ComponentFixture<SvdgsLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SvdgsLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SvdgsLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
