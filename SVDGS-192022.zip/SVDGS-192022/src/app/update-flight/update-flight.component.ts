import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { userMappingService } from '../services/user-mapping-service';
import {userService} from '../schedule-flight/schedule-flight-service';
import {schedule_flight_modal} from '../schedule-flight/schedule-flight-modal';
import { Country } from '../schedule-flight/country'
import { Airport } from '../schedule-flight/airport'


@Component({
  selector: 'app-update-flight',
  templateUrl: './update-flight.component.html',
  styleUrls: ['./update-flight.component.css']
})
export class UpdateFlightComponent implements OnInit {
  // searchNo:String ="abc";
  airportCodeList:String[]=[];
  flightIdList:String[]=[];
  FlightNoList:String[]=[];
  id:String
  countries :Country[]=[];
  airports : Airport[]=[];
  
  
  mappingModal: FormGroup;
  dateNow :any
  AOCC_SVDGS_Airport_Code:string
  countryCode:string

  constructor(private route: ActivatedRoute,
    private router: Router,
    public service :userMappingService,private formBuilder: FormBuilder,
    public serviceUser :userService) { }

  ngOnInit() {

    this.id =this.route.snapshot.paramMap.get('id');

    this.fetchData();

    jQuery(document).ready(function () {
      (<any>jQuery('#updFlightForm')).validate();
    });

    this.getCountryData();
    this.getAirports();
  }

  getCountryData()
  {

     this.countries =[{"countryCode":"India","countryName":"India"},
    ]
  }

  

  onChangeAirportCode()
  {

  }
  onChangeArrivalDept()
  {
    
  }

  onChangeCountry()
  {
    
  }

  
  fetchData(){
    this.mappingModal = this.formBuilder.group({
      AOCC_SVDGS_Unique_Flight_ID: [],
      AOCC_SVDGS_Airport_Code: [''],
      // flightId: [''],
      AOCC_SVDGS_Flight_No: [''],
      AOCC_SVDGS_AC_Type: [''],
      AOCC_SVDGS_Arr_Dep: [''],
      AOCC_SVDGS_Stand: [''],
      AOCC_SVDGS_AT_AD: [''],
      AOCC_SVDGS_ST_AD: [''],
      AOCC_SVDGS_ET_AD:[''],
      AOCC_SVDGS_Flight_Qualifier:[''],
      AOCC_SVDGS_Reg_No:[''],
      AOCC_SVDGS_Bag_Belt:[''],
      AOCC_SVDGS_Flight_Status:[''],
      AOCC_SVDGS_VIA:[''],
      AOCC_SVDGS_Code_Share_Flight:[''],
      AOCC_SVDGS_O_D:[''],
      searchNo:[''],
      chocksOn:[''],
      chockOff:[''],
      difference:[''],
      activate:[''],
      countryCode:[''],
      chockOffString:[''],
      chockonString:[''],
     
      

    });
    
  this.serviceUser.getFlightDetails(this.id).subscribe((data:schedule_flight_modal)=>{
      // this.modal=data;
      data.AOCC_SVDGS_AT_AD = data.AOCC_SVDGS_AT_AD.substring(0,16);
      data.AOCC_SVDGS_ST_AD = data.AOCC_SVDGS_ST_AD.substring(0,16);
      data.AOCC_SVDGS_ET_AD = data.AOCC_SVDGS_ET_AD.substring(0,16);
      
      console.log('getFlightDetails page getFlightDetails',data)

      this.mappingModal.patchValue(data);
      this.dateNow  = new Date();
      });

    

    // this.serviceUser.getAll().subscribe((data :[])=>{
    //   console.log('update-flight page get all flight',data)
    //   this.modal=data;

    //   this.modal.forEach((element:schedule_flight_modal) => {
    //     this.FlightNoList.push(element.flightNo);
    //     this.flightIdList.push(element.flightId);
    //     this.airportCodeList.push(element.airportCode);
    //     // console.log( "element.stad  ",element.stad,"  ",element.stad.substring(0,23))
    //     element.stad=element.stad.substring(0,23);
    //     element.atad=element.atad.substring(0,23);
    //     element.etad=element.etad.substring(0,23);
    //   });

    // })

    // console.log(" this.FlightNoList", this.FlightNoList);

  }


  getAirports(){
    console.log('getAirports')
    this.service.getAirports().subscribe((data :[] )=>{
        console.log('getAirports',data)
        this.airports=data;
        // this.filteredModel=data;
      })
   
  }

  formSubmit(formData) {
    console.log("Logged in Successfully schedule flight", formData.value);
    formData.saveOrUpdate = true
    this.serviceUser.getPosts(formData).subscribe(data => {
       console.log('abcdefef aa gya ', data)
    },
      error => console.log(error));


    let id = 8;
  


  }

  // convertStrToDate(strDate:string )
  // { let pipe= new  DatePipe('en-US');

  //   this.pipe.transform(now, 'short');

  //    return new Date(strDate);
  // }



  


  onKeydown(event) {
    console.log("aa",this.mappingModal.value.searchNo);
    if (event.key === "Enter") {
      // this.modal.forEach((a:schedule_flight_modal) => {
      //   if(a.flightId==this.mappingModal.value.searchNo || a.flightNo==this.mappingModal.value.searchNo ){
      //     this.mappingModal.setValue(a);
      //   }else{

      //   }
      // });
    }
  }


}
