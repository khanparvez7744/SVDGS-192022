import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as $ from 'jquery'
import { userMappingService } from '../services/user-mapping-service';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  constructor(private _router: Router, public service: userMappingService, private formBuilder: FormBuilder) { }
  msg: string
  loginPage: boolean = false;
  ngOnInit() {
    this.service.loginPage = false;
  }
  mappingModal = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl(''),
  });
  login(formData) {
    console.log("Logged in Successfully");
    this.service.login(formData).subscribe((data: any) => {
      console.log('data all user role', data)
      this.service.loginPage = true;
      this._router.navigate(['dash']);
    },
      error => {
        this.msg = "Invalid username and password"
        console.log(error)
      },
    )
  }
}